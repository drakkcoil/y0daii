# y0daii IRC Client v1.0.7 Installer

This package contains the y0daii IRC Client application and scripts for a professional installation experience on Windows.

## Installation Instructions

1.  **Extract** this zip file to a temporary location (e.g., your Downloads folder).
2.  **Run install.bat as administrator**: Right-click on install.bat and select "Run as administrator".
3.  **Follow the prompts**: The installer will guide you through the process, including an option to create a desktop shortcut.
4.  The application will be installed to C:\Program Files\y0daiiIRC.

## Uninstallation Instructions

1.  **Via Control Panel**: Go to "Add or remove programs", find "y0daii IRC Client v1.0.7", and click "Uninstall".
2.  **Via Script**: Navigate to the installation directory (C:\Program Files\y0daiiIRC) and run uninstall.bat as administrator.

## System Requirements

-   Windows 10/11 (x64)
-   No .NET runtime installation required (self-contained application)
-   Approximately 100MB of disk space
