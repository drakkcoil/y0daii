﻿# y0daii IRC Client v1.0.7

## Installation Instructions

1. **Run as Administrator**: Right-click on install.bat and select "Run as administrator"
2. **Follow the prompts**: The installer will guide you through the process
3. **Optional Desktop Shortcut**: Choose whether to create a desktop shortcut
4. **Complete**: The application will be installed to Program Files

## Features

- Modern Material Design UI
- Comprehensive IRC protocol support
- Built-in update system
- Professional architecture
- Self-contained (no additional dependencies required)

## Uninstallation

To uninstall:
1. Go to Control Panel > Programs and Features
2. Find "y0daii IRC Client" and click Uninstall
3. Or run uninstall.bat as administrator

## System Requirements

- Windows 10/11 (x64)
- No additional software required

## Support

For support and updates, visit: https://github.com/drakkcoil/y0daii
